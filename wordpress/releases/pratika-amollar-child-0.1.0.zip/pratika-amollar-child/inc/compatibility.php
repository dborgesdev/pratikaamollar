<?php
defined('ABSPATH') || exit;

/**
 * No guessed WoodMart hooks or wrappers. An audited adapter must preserve the
 * installed parent's structure and hooks, replacing only its visual chrome.
 * Empty manifest intentionally delegates both templates to the parent.
 */
function pa_child_adapter_ready() {
    static $ready = null;
    if ($ready !== null) {
        return $ready;
    }
    $ready = false;
    $file = get_stylesheet_directory() . '/inc/parent-contract.json';
    if (!is_readable($file)) {
        return false;
    }
    $contract = json_decode((string) file_get_contents($file), true);
    if (!is_array($contract) || empty($contract['reviewed']) || empty($contract['files']) || empty($contract['adapters'])) {
        return false;
    }
    foreach (array('style.css', 'header.php', 'footer.php') as $required) {
        if (empty($contract['files'][$required])) {
            return false;
        }
    }
    foreach ($contract['files'] as $path => $expected) {
        if (!is_string($path) || strpos($path, '..') !== false || (!preg_match('~^[a-zA-Z0-9_/-]+\.php$~D', $path) && $path !== 'style.css')) {
            return false;
        }
        $source = get_template_directory() . '/' . $path;
        if (!is_readable($source) || !is_string($expected) || !hash_equals($expected, hash_file('sha256', $source))) {
            return false;
        }
    }
    // Both halves must match together; never mix parent and child wrappers.
    foreach (array('header', 'footer') as $name) {
        $expected = isset($contract['adapters'][$name]) ? $contract['adapters'][$name] : '';
        $adapter = get_stylesheet_directory() . '/adapters/' . $name . '.php';
        if (!is_readable($adapter) || !is_string($expected) || !hash_equals($expected, hash_file('sha256', $adapter))) {
            return false;
        }
    }
    $ready = true;
    return true;
}
function pa_child_load_shell($name) {
    if (!in_array($name, array('header', 'footer'), true)) {
        return;
    }
    if (pa_child_adapter_ready()) {
        require get_stylesheet_directory() . '/adapters/' . $name . '.php';
        return;
    }
    // Standard WP child-template delegation; no rewrite or output buffering.
    require get_template_directory() . '/' . $name . '.php';
}
