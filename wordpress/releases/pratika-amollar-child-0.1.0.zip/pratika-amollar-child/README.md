# Pratika Amollar — tema filho WoodMart 0.1.0

**ZIP instalável de preparação. A substituição global do header/footer está BLOQUEADA por falta dos templates da versão instalada do pai. Ativar este pacote ainda mantém o visual do pai. Não é a integração definitiva homologada.**

## O que foi implementado

- Header PHP real, estático, sem categoria/busca/wishlist/contador/minicarrinho; logo oficial, dois links, conta e carrinho.
- Footer PHP real com identidade, contatos confirmados, quatro políticas e crédito exato Smart Local.
- CSS responsivo fiel aos tokens do React e acabamento de elementos WooCommerce sem alterar campos, AJAX, gateways ou sessões.
- Fontes Manrope e DM Serif Display locais com OFL e ícones SVG estáticos; nenhum asset da prévia.
- JS pequeno, sem biblioteca: toggle, ARIA, Escape com foco, fechamento ao clicar fora, navegar, sair por teclado e trocar breakpoint. Sem JS, links do menu continuam visíveis.
- Configuração de URLs em `inc/config.php`: alterar somente `frontend_origin` para `https://pratikaamollar.com.br` quando autorizado. `operational_origin` permanece na loja. Sem redirecionamentos.

## Bloqueio concreto e arquivos necessários

O repositório não contém o WoodMart comprado/instalado. A documentação pública não é prova da estrutura dessa instalação. O footer fecha contêineres abertos pelo header; recriar essas tags ou remover hooks genéricos pode quebrar checkout e endpoints.

Para concluir o adaptador, fornecer cópias **da mesma versão instalada**, sem credenciais:

1. `wp-content/themes/woodmart/style.css` (versão e identidade do pai).
2. `wp-content/themes/woodmart/header.php` e `footer.php` integrais.
3. `wp-content/themes/woodmart/functions.php` e `inc/enqueue.php`, se esse último existir, para conferir carregamentos/callbacks.
4. Todos os `header-*.php` e `footer-*.php` existentes na raiz, além de `page.php` e `page-*.php` usados pelas páginas operacionais. Templates nomeados podem ter precedência sobre o genérico do filho.
5. Arquivos chamados por esses templates que emitam header, mobile menu, minicarrinho, prefooter, copyright ou barras extras. Seus nomes serão extraídos dos arquivos reais; não se presume estrutura de diretórios de outra versão.
6. Se já houver tema filho ativo: seus `functions.php`, overrides de header/footer e CSS (sem secrets), para integrar sem perder customizações.

O campo `Template: woodmart` foi confirmado pelo ZIP oficial da XTemos, vinculado na documentação do fornecedor. A pasta real do pai deve continuar sendo `woodmart`; se foi renomeada, conferir antes da instalação. Não renomear o pai como solução improvisada.

## Como o adaptador será concluído

Após inspeção, criar `adapters/header.php` e `adapters/footer.php` preservando estrutura e chamadas reais do pai (`wp_head`, `wp_body_open`, `wp_footer` e hooks necessários), substituindo somente emissão da moldura antiga por `pa_child_render_header()` e `pa_child_render_footer()`. O header adaptado deve fornecer `id="pa-content"` e destino focável no contêiner correto. Não substituir checkout/conta por templates próprios.

O contrato `inc/parent-contract.json` guarda hashes dos arquivos auditados do pai e dos dois adaptadores; só habilita quando ambos são válidos. **Não mudar `reviewed` para true para contornar o bloqueio.** Arquivo ausente ou pai atualizado faz o pacote voltar ao pai. É uma proteção de compatibilidade, não um mecanismo contra código malicioso do servidor. Atualizações exigem nova inspeção, testes e nova versão do pacote.

Não há `remove_all_actions`, remoção por seletor DOM, buffering/regex de HTML, gravação de opções ou importação automática de templates Elementor. Nenhuma configuração de pagamento/frete/cache é alterada. Os arquivos genéricos `header.php` e `footer.php` do filho apenas delegam ao pai enquanto o adaptador não existe.

## Instalação para inspeção autorizada

1. Fazer backup completo de arquivos e banco. Exportar Theme Settings, header builder, templates Elementor e registrar tema ativo, versão do pai, menus, widgets e presets. Manter acesso ao painel da hospedagem para rollback.
2. Confirmar pai `woodmart` instalado, versão PHP >=7.4 e ausência de outro filho que precise ser incorporado. Não instalar por cima de outro filho.
3. Em **staging autorizado**: WordPress → Aparência → Temas → Adicionar novo → Enviar tema → selecionar `pratika-amollar-child-0.1.0.zip` → Instalar. Não precisa criar menus/widgets nem reconstruir Elementor.
4. A ativação atual mostrará aviso de integração pendente e continuará com os componentes do pai. Essa é a proteção esperada deste ZIP. **Não ativar na loja esperando a troca visual definitiva.**
5. Depois de receber o pacote com adaptador revisado, repetir a instalação e verificar cada página. Não reutilizar o loader ou HTML Blocks do pacote antigo `visual-integration`; são alternativas históricas e duplicariam recursos.

Ativação não migra menus, widgets ou theme mods entre slugs, não exclui opções e não instala/desativa plugins. O WordPress pode mudar as atribuições aparentes ao trocar o tema; comparar com o registro antes de ativar e restaurar atribuições apenas se necessário. O tema não fornece configuração administrativa nem faz chamadas HTTP.

## Verificações imediatas após a integração revisada

- Checkout clássico e carrinho nativo vazio/fallback; conta/login/cadastro/recuperação; dashboard/pedidos/detalhes/endereços; rastreamento; order-received e order-pay.
- Uma única moldura, sem busca/menu/minicarrinho/prefooter/copyright/barras antigas, incluindo mobile. Nenhum componente antigo apenas escondido e focável.
- 320, 375, 768, 1024 e 1440px; sem overflow; scroll sem sticky; menu e foco por teclado; reduced-motion e zoom 200%.
- CSS do pai continua carregado uma vez; arquivos locais do filho sem 404; páginas/shortcodes existentes preservados. Canvas do Elementor pode ignorar header/footer do tema: conferir template de página e preferir padrão/full width sem mudar conteúdo.
- Ponte v2 e persistência de sessão, atualização de frete/AJAX, mensagens e gateways em sandbox isolado. Não gerar pedido ou cobrança real. Sem homologação de Mercado Pago nesta entrega.
- Links legais apontam a minutas ainda não publicadas nesta etapa: só entram na experiência remota depois da publicação autorizada e revisão jurídica; não alterar checkbox/configurações de termos agora.

## Rollback

Reativar o tema que estava ativo em Aparência → Temas. Não desinstalar pai, WooCommerce, ponte ou cache. Conferir menus/widgets/presets e restaurar os registros/exportações se necessário. Se o painel não abrir, usar o painel da hospedagem para renomear **apenas a pasta do novo filho** e restaurar o tema anterior com suporte da hospedagem; não excluir banco/pedidos/clientes. Conferir checkout, conta e sessão após voltar.

## Manutenção e fontes

O tema não é homologado com o WoodMart real enquanto os arquivos acima não forem inspecionados. CSS não alcança conteúdo interno de iframes; nenhum campo fiscal/boleto foi alterado. O rastreamento fora do wrapper Woo recebe acabamento apenas no campo confirmado `search_tracking_code`, evitando suposições sobre o plugin.

- https://woodmarttheme.com/docs/set-up-a-child-theme/
- ZIP mínimo oficial: https://woodmart.xtemos.com/plugins/woodmart-child.zip
- Footer publicado pelo suporte oficial (evidência histórica, não contrato da instalação): https://xtemos.com/forums/topic/footer-php/
- Templates e caminhos WordPress: https://developer.wordpress.org/themes/classic-themes/basics/linking-theme-files-directories/

Sem commit, push, merge, deploy ou alteração remota nesta entrega.
